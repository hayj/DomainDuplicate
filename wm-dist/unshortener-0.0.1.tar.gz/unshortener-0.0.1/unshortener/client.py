# coding: utf-8

from unshortener import Unshortener

if __name__ == '__main__':
    print("yo")